const Home = () => (
    <h1>THIS IS HOMEPAGE</h1>
)

export default Home;