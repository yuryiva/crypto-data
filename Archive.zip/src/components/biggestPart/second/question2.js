import React from 'react'

import '../big-part/biggestPart.css'

const Question2 = () => {
    return (
        <div className='questions'>
            <b>Bitcoin Exchange</b>
            <p>ghdfhdfhthdfgdfhdsfhjfgdhjdfhjdgfhjdgf</p>
        </div>
    )
}

export default Question2;
