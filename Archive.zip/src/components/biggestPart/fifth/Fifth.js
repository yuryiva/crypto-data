const Fifth = () => (
    <div className='questions'>
        <b>The 10 Most Important Cryptocurrencies Other Than Bitcoin</b>
    </div>
)

export default Fifth;