const Fourth = () => (
    <div className='questions'>
        <b>What Are the Advantages of Paying With Bitcoin?</b>
    </div>
)

export default Fourth;