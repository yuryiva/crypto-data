const Third = () => (
    <div className='questions'>
        <b>Should You Buy Gold Or Bitcoin?</b>
    </div>
)

export default Third;