import React from 'react';
import '../big-part/biggestPart.css';

const Question1 = () => {

    return (
        <div className='questions'>
            <b>What are the Safest Ways to Store Bitcoin?</b>
        </div>
    )
}

export default Question1;
